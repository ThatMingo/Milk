#!/bin/zsh
set -euo pipefail

project="${0:A:h}"
export DEVELOPER_DIR="${DEVELOPER_DIR:-/Applications/Xcode.app/Contents/Developer}"

# Milk supplies this independent, dynamically linked author SDK.
sdk="${MILK_EXTENSION_SDK:-/Applications/Milk.app/Contents/Resources/ExtensionSDK}"
[[ -f "$sdk/libMilkExtensionKit.dylib" ]] || {
  print -u2 "Cannot find MilkExtensionKit SDK at: $sdk"
  print -u2 "Set MILK_EXTENSION_SDK to Milk.app/Contents/Resources/ExtensionSDK, or your built SDK directory."
  exit 1
}
sdkModules="$sdk/Modules"
[[ -d "$sdkModules" ]] || sdkModules="$sdk"

bundle="${1:-$project/build/OMLXSidebar.milkext}"
mkdir -p "$bundle/Contents/MacOS" "$bundle/Contents/Resources"
cp "$project/manifest.json" "$bundle/Contents/Resources/manifest.json"
python3 - "$bundle" <<'PY'
import json, pathlib, plistlib, sys
root=pathlib.Path(sys.argv[1])
manifest=json.loads((root/'Contents/Resources/manifest.json').read_text())
(root/'Contents/Info.plist').write_bytes(plistlib.dumps({
    'CFBundleIdentifier':manifest['id'],
    'CFBundleName':manifest['name'],
    'CFBundlePackageType':'BNDL',
    'CFBundleExecutable':manifest['executable'],
    'NSPrincipalClass':manifest['principalClass'],
    'CFBundleShortVersionString':manifest['version'],
}))
PY

xcrun swiftc -swift-version 5 -target arm64-apple-macosx26.0 \
  -parse-as-library -emit-library -Xlinker -bundle \
  -module-name OMLXSidebar \
  -I "$sdkModules" -L "$sdk" -lMilkExtensionKit \
  "$project/Telemetry.swift" \
  "$project/OMLXConfiguration.swift" \
  "$project/OMLXSidebarExtension.swift" \
  -o "$bundle/Contents/MacOS/OMLXSidebar"

# Milk accepts ad-hoc signed local packages after the user's trust approval.
codesign --force --sign - "$bundle"
print "Built: $bundle"
