import Foundation
import SwiftUI
import Combine
import MilkExtensionKit

// Standalone, trusted native extension. Registers exactly ONE Milk sidebar tab.
@MainActor public final class OMLXSidebarExtension: MilkExtension {
    private var dashboard: OMLXDashboardModel?

    public override func activate(context: any ExtensionContext) async throws {
        guard let network = context.network else {
            throw DashboardNetworkError.missingCapability
        }
        let model = OMLXDashboardModel(network: network)
        self.dashboard = model
        try context.contributions.sidebar(.init(
            id: "dashboard",
            title: "oMLX",
            systemImage: "waveform.path.ecg",
            minimumSize: CGSize(width: 280, height: 300),
            topbar: false
        ) { _ in
            AnyView(OMLXDashboardView(model: model))
        })
    }

    public override func deactivate() async {
        dashboard = nil
    }
}

private enum DashboardNetworkError: LocalizedError {
    case missingCapability, statusCode(Int)
    var errorDescription: String? {
        switch self {
        case .missingCapability: return "Milk did not grant the network capability."
        case .statusCode(let code): return code == 401 ? "oMLX authentication failed." : "oMLX returned HTTP \(code)."
        }
    }
}

@MainActor private final class OMLXDashboardModel: ObservableObject {
    @Published private(set) var connected = false
    @Published private(set) var hasChecked = false
    @Published private(set) var live = LiveReading()
    @Published private(set) var totals = TotalsReading()

    private let network: any ExtensionNetwork
    private var lastPrefill: (id: String, processed: Int, time: TimeInterval)?
    private var lastPrefillSpeed: (speed: Double, time: TimeInterval)?

    init(network: any ExtensionNetwork) { self.network = network }

    /// Called by SwiftUI only while this sidebar tab is visible.
    /// Cancellation stops future requests; one pending request may finish.
    func monitorWhileVisible() async {
        // Fast and slow polls are independent: the expensive stats request
        // cannot block the 0.5-second live-activity refresh cycle.
        await withTaskGroup(of: Void.self) { group in
            group.addTask { await self.liveLoop() }
            group.addTask { await self.totalsLoop() }
        }
    }

    private func liveLoop() async {
        await refreshLive()
        while !Task.isCancelled {
            do {
                try await Task.sleep(nanoseconds: connected ? 500_000_000 : 2_000_000_000)
            } catch { break }
            if Task.isCancelled { break }
            await refreshLive()
        }
    }

    private func totalsLoop() async {
        while !Task.isCancelled {
            if connected { await refreshTotals() }
            do {
                try await Task.sleep(nanoseconds: connected ? 5_000_000_000 : 1_000_000_000)
            } catch { break }
        }
    }

    private func get(_ connection: OMLXConnection, path: String,
                     query: [URLQueryItem] = [], timeout: TimeInterval = 3) async throws -> Data {
        let request = connection.request(path: path, query: query, timeout: timeout)
        let (data, response) = try await network.data(for: request)
        guard (200..<300).contains(response.statusCode) else {
            throw DashboardNetworkError.statusCode(response.statusCode)
        }
        return data
    }

    private func refreshLive() async {
        do {
            // Re-read existing oMLX configuration; no key entry or duplicate secret store.
            let connection = try OMLXConnection.detect()
            let data = try await get(connection, path: "/admin/api/activity", timeout: 3)
            try Task.checkCancellation()
            var reading = try TelemetryParser.live(from: data)
            updateMeasuredSpeed(&reading)
            self.live = reading
            self.connected = true
            self.hasChecked = true
        } catch is CancellationError {
            return
        } catch {
            // No per-poll logging and no repeated error dialog. Also do not
            // expose the endpoint/key or a potentially sensitive error body.
            self.connected = false
            self.hasChecked = true
            self.lastPrefill = nil
            self.lastPrefillSpeed = nil
        }
    }

    private func refreshTotals() async {
        do {
            let connection = try OMLXConnection.detect()
            let data = try await get(connection, path: "/admin/api/stats",
                                     query: [URLQueryItem(name: "scope", value: "alltime")], timeout: 5)
            try Task.checkCancellation()
            self.totals = try TelemetryParser.totals(from: data)
        } catch {
            // Preserve last known totals; never flood the server or Milk logs.
        }
    }

    /// Some oMLX/Splash versions report prefill speed as 0 even while token
    /// progress increases. Use two real snapshots to measure it instead.
    private func updateMeasuredSpeed(_ reading: inout LiveReading) {
        let now = ProcessInfo.processInfo.systemUptime
        guard reading.phase == .processing else {
            lastPrefill = nil
            lastPrefillSpeed = nil
            return
        }
        let id = reading.requestID ?? "default"
        if let previous = lastPrefill, previous.id == id,
           reading.tokens >= previous.processed {
            let delta = now - previous.time
            if delta >= 0.25, delta < 5, reading.tokens > previous.processed {
                let measured = Double(reading.tokens - previous.processed) / delta
                if measured.isFinite && measured > 0 {
                    lastPrefillSpeed = (measured, now)
                }
            }
        }
        lastPrefill = (id, reading.tokens, now)
        if reading.speed == nil || reading.speed == 0 {
            if let last = lastPrefillSpeed, now - last.time < 2.0 {
                reading.speed = last.speed
            } else {
                reading.speed = nil // Unknown is not falsely displayed as 0 tok/s.
            }
        }
    }
}

private enum DashboardPalette {
    static let background = Color(red: 14/255, green: 13/255, blue: 19/255)
    static let text = Color(red: 235/255, green: 233/255, blue: 229/255)
    static let muted = Color(red: 102/255, green: 99/255, blue: 111/255)
    static let track = Color(red: 45/255, green: 43/255, blue: 54/255)
    static let green = Color(red: 50/255, green: 192/255, blue: 84/255)
    static let blue = Color(red: 0/255, green: 153/255, blue: 255/255)
    static let amber = Color(red: 233/255, green: 179/255, blue: 57/255)
    static let red = Color(red: 241/255, green: 73/255, blue: 85/255)
}

@MainActor private struct OMLXDashboardView: View {
    @ObservedObject var model: OMLXDashboardModel

    var body: some View {
        GeometryReader { geometry in
            let scale = min(1, max(0.60, geometry.size.width / 556.0))
            ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 0) {
                    Text("oMLX")
                        .font(.system(size: 63 * scale, weight: .bold, design: .rounded))
                        .tracking(-2 * scale)
                        .foregroundStyle(DashboardPalette.text)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.bottom, 34 * scale)

                    infoRow("TOTAL PREFILL TOKENS",
                            value: model.connected ? DashboardFormat.tokenCount(model.totals.prefillTokens) + " tok" : "—",
                            scale: scale)
                        .padding(.bottom, 36 * scale)
                    infoRow("TOTAL CACHED TOKENS",
                            value: model.connected ? DashboardFormat.tokenCount(model.totals.cachedTokens) + " tok" : "—",
                            scale: scale)
                        .padding(.bottom, 35 * scale)
                    infoRow("MODEL", value: model.connected ? model.live.modelID ?? "—" : "—",
                            scale: scale, middleTruncation: true)
                        .padding(.bottom, 34 * scale)

                    liveSection(scale: scale)
                        .padding(.bottom, 36 * scale)
                    memorySection(scale: scale)
                        .padding(.bottom, 36 * scale)
                    cacheSection(scale: scale)
                        .padding(.bottom, 36 * scale)
                    ssdSection(scale: scale)
                }
                .padding(.horizontal, 28 * scale)
                .padding(.top, 25 * scale)
                .padding(.bottom, 30 * scale)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DashboardPalette.background)
        }
        .background(DashboardPalette.background)
        .task { await model.monitorWhileVisible() }
    }

    private func infoRow(_ label: String, value: String, scale: CGFloat,
                         middleTruncation: Bool = false) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8 * scale) {
            Text(label)
                .font(.system(size: 18 * scale, weight: .bold, design: .monospaced))
                .tracking(1.2 * scale)
                .foregroundStyle(DashboardPalette.muted)
                .lineLimit(1)
                .fixedSize(horizontal: true, vertical: false)
            Spacer(minLength: 4)
            Text(value)
                .font(.system(size: 19 * scale, weight: .bold, design: .monospaced))
                .foregroundStyle(DashboardPalette.text)
                .monospacedDigit()
                .lineLimit(1)
                .truncationMode(middleTruncation ? .middle : .tail)
                .minimumScaleFactor(0.7)
        }
    }

    private func liveSection(scale: CGFloat) -> some View {
        let state = model.live
        let phase = model.connected ? state.phase : .idle
        let color: Color = !model.connected ? DashboardPalette.muted :
            (phase == .processing ? DashboardPalette.blue :
             (phase == .generating ? DashboardPalette.green : DashboardPalette.muted))
        let title: String = !model.hasChecked ? "CONNECTING" :
            (!model.connected ? "DISCONNECTED" :
                (phase == .processing ? "PROCESSING \(Int((state.progress * 100).rounded()))%" :
                 phase == .generating ? "GENERATING" : "IDLE"))
        let count = model.connected ? DashboardFormat.tokenCount(state.tokens) + " tok" : "—"
        let speed = model.connected ? (phase == .idle ? "0.0 tok/s" : DashboardFormat.tokensPerSecond(state.speed)) : "—"

        return VStack(alignment: .leading, spacing: 8 * scale) {
            HStack(alignment: .firstTextBaseline, spacing: 9 * scale) {
                Text(title)
                    .font(.system(size: 18 * scale, weight: .bold, design: .monospaced))
                    .foregroundStyle(color)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                Spacer(minLength: 4)
                Text(count)
                    .font(.system(size: 18 * scale, weight: .bold, design: .monospaced))
                    .foregroundStyle(DashboardPalette.muted)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                Text(speed)
                    .font(.system(size: 18 * scale, weight: .bold, design: .monospaced))
                    .foregroundStyle(DashboardPalette.muted)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            NativeMeter(fill: color,
                        progress: phase == .processing ? state.progress : 1,
                        background: DashboardPalette.track,
                        height: 10 * scale)
        }
    }

    private func memorySection(scale: CGFloat) -> some View {
        let value = model.connected ? model.live.memory : MemoryReading()
        return VStack(alignment: .leading, spacing: 8 * scale) {
            infoRow("RAM", value:
                "\(DashboardFormat.gigaBytes(value.used)) / \(DashboardFormat.gigaBytes(value.soft)) / \(DashboardFormat.gigaBytes(value.hard))",
                scale: scale)
            NativeMeter(fill: DashboardPalette.amber,
                        progress: DashboardFormat.ratio(value.used, value.hard),
                        background: DashboardPalette.track,
                        marker: value.soft != nil && value.hard != nil ?
                            DashboardFormat.ratio(value.soft, value.hard) : nil,
                        height: 10 * scale)
        }
    }

    private func cacheSection(scale: CGFloat) -> some View {
        let percent = model.connected ? model.totals.cacheHitPercent : nil
        return VStack(alignment: .leading, spacing: 8 * scale) {
            infoRow("CACHE HIT", value: DashboardFormat.percent(percent), scale: scale)
            NativeMeter(fill: DashboardPalette.red,
                        progress: percent.map { min(1, max(0, $0 / 100)) } ?? 0,
                        background: DashboardPalette.track,
                        height: 10 * scale)
        }
    }

    private func ssdSection(scale: CGFloat) -> some View {
        let used = model.connected ? model.totals.ssdUsedBytes : nil
        let limit = model.connected ? model.totals.ssdLimitBytes : nil
        return VStack(alignment: .leading, spacing: 8 * scale) {
            infoRow("SSD CACHE", value: "\(DashboardFormat.gigaBytes(used)) / \(DashboardFormat.gigaBytes(limit))", scale: scale)
            NativeMeter(fill: DashboardPalette.red,
                        progress: DashboardFormat.ratio(used, limit),
                        background: DashboardPalette.track,
                        height: 10 * scale)
        }
    }
}

/// Pure SwiftUI geometry. Soft limit is a slim marker ON the RAM bar,
/// never a second line of labels beneath it.
private struct NativeMeter: View {
    let fill: Color
    let progress: Double
    let background: Color
    var marker: Double? = nil
    let height: CGFloat

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule().fill(background)
                Capsule().fill(fill)
                    .frame(width: geometry.size.width * min(1, max(0, progress)))
                if let marker, marker > 0, marker < 1 {
                    Rectangle()
                        .fill(Color.white.opacity(0.28))
                        .frame(width: 1.5, height: height)
                        .offset(x: geometry.size.width * marker)
                }
            }
            .frame(height: height)
            .clipped()
        }
        .frame(height: height)
    }
}
