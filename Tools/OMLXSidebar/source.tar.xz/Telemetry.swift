import Foundation

// Mirrors oMLX /admin/api/activity and /admin/api/stats, but only the read-only
// values shown in the dashboard. There are no guessed telemetry values.

enum ModelPhase: Equatable {
    case idle
    case processing
    case generating
}

struct MemoryReading: Equatable {
    var used: Double?
    var soft: Double?
    var hard: Double?
}

struct LiveReading: Equatable {
    var modelID: String?
    var phase: ModelPhase = .idle
    var requestID: String?
    var tokens: Int = 0
    var totalTokens: Int = 0
    var speed: Double?
    var memory: MemoryReading = MemoryReading()

    var progress: Double {
        guard phase == .processing, totalTokens > 0 else { return phase == .processing ? 0 : 1 }
        return min(1, max(0, Double(tokens) / Double(totalTokens)))
    }
}

struct TotalsReading: Equatable {
    var prefillTokens: Int?
    var cachedTokens: Int?
    var cacheHitPercent: Double?
    var ssdUsedBytes: Double?
    var ssdLimitBytes: Double?
}

enum TelemetryParsingError: Error { case unexpectedJSON }

enum TelemetryParser {
    static func live(from data: Data) throws -> LiveReading {
        let root = try object(data)
        let modelsRoot = dictionary(root["active_models"]) ?? [:]
        let models = modelsRoot["models"] as? [[String: Any]] ?? []
        let first = models.first
        let pressure = dictionary(modelsRoot["memory_pressure"]) ?? [:]

        var reading = LiveReading()
        reading.modelID = first?["id"] as? String
        let pressureEnabled = pressure["enabled"] as? Bool ?? false
        reading.memory = MemoryReading(
            used: pressureEnabled ? (number(pressure["current_bytes"]) ?? number(modelsRoot["model_memory_used"]))
                                  : number(modelsRoot["model_memory_used"]),
            soft: pressureEnabled ? number(pressure["soft_bytes"]) : nil,
            hard: pressureEnabled ? (number(pressure["hard_bytes"]) ?? number(modelsRoot["model_memory_max"]))
                                  : number(modelsRoot["model_memory_max"])
        )

        guard let model = first else { return reading }

        if let firstPrefill = (model["prefilling"] as? [[String: Any]])?.first {
            reading.phase = .processing
            reading.requestID = firstPrefill["request_id"] as? String
            reading.tokens = max(0, integer(firstPrefill["processed"]) ?? 0)
            reading.totalTokens = max(0, integer(firstPrefill["total"]) ?? 0)
            reading.speed = nonnegative(number(firstPrefill["speed"]))
        } else if let firstGeneration = (model["generating"] as? [[String: Any]])?.first {
            reading.phase = .generating
            reading.requestID = firstGeneration["request_id"] as? String
            reading.tokens = max(0, integer(firstGeneration["generated_tokens"]) ?? 0)
            reading.speed = nonnegative(number(firstGeneration["tokens_per_second"]))
        }
        return reading
    }

    static func totals(from data: Data) throws -> TotalsReading {
        let root = try object(data)
        let runtime = dictionary(root["runtime_cache"]) ?? [:]
        return TotalsReading(
            prefillTokens: integer(root["total_prompt_tokens"]),
            cachedTokens: integer(root["total_cached_tokens"]),
            cacheHitPercent: nonnegative(number(root["cache_efficiency"])),
            ssdUsedBytes: nonnegative(number(runtime["total_size_bytes"])),
            ssdLimitBytes: nonnegative(number(runtime["disk_max_bytes"]))
        )
    }

    private static func object(_ data: Data) throws -> [String: Any] {
        guard let value = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TelemetryParsingError.unexpectedJSON
        }
        return value
    }

    private static func dictionary(_ value: Any?) -> [String: Any]? { value as? [String: Any] }

    private static func number(_ value: Any?) -> Double? {
        guard let value = value as? NSNumber else { return nil }
        let number = value.doubleValue
        return number.isFinite ? number : nil
    }

    private static func integer(_ value: Any?) -> Int? {
        guard let number = number(value), number >= 0, number <= Double(Int.max) else { return nil }
        return Int(number)
    }

    private static func nonnegative(_ value: Double?) -> Double? {
        guard let value, value >= 0 else { return nil }
        return value
    }
}

// Display formatting lives outside SwiftUI so it can be tested on any platform.
enum DashboardFormat {
    static func tokenCount(_ count: Int?) -> String {
        guard let count else { return "—" }
        if count >= 1_000_000 { return String(format: "%.2fM", Double(count) / 1_000_000) }
        if count >= 10_000 { return String(format: "%.1fk", Double(count) / 1_000) }
        return "\(count)"
    }

    static func gigaBytes(_ bytes: Double?) -> String {
        guard let bytes, bytes.isFinite, bytes >= 0 else { return "—" }
        return String(format: "%.1f GB", bytes / 1_073_741_824)
    }

    static func percent(_ number: Double?) -> String {
        guard let number, number.isFinite, number >= 0 else { return "—" }
        return String(format: "%.2f%%", min(100, number))
    }

    static func tokensPerSecond(_ speed: Double?) -> String {
        guard let speed, speed.isFinite, speed >= 0 else { return "— tok/s" }
        return String(format: "%.1f tok/s", speed)
    }

    static func ratio(_ numerator: Double?, _ denominator: Double?) -> Double {
        guard let numerator, let denominator, numerator.isFinite, denominator.isFinite, denominator > 0 else { return 0 }
        return min(1, max(0, numerator / denominator))
    }
}
