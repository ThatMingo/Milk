import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Reads the same oMLX config path hierarchy as oMLX's macOS AppConfig.
/// The key is kept in memory only, never written into Milk extension storage.
struct OMLXConnection {
    let baseURL: URL
    let apiKey: String?

    enum DetectionError: LocalizedError {
        case nonlocalHost
        case invalidPort
        case invalidConfig
        var errorDescription: String? {
            switch self {
            case .nonlocalHost: return "oMLX is not configured on this Mac's loopback address."
            case .invalidPort: return "oMLX's configured port is invalid."
            case .invalidConfig: return "oMLX settings could not be read."
            }
        }
    }

    static func detect() throws -> OMLXConnection {
        let env = ProcessInfo.processInfo.environment
        let home = FileManager.default.homeDirectoryForCurrentUser

        // oMLX precedence: OMLX_BASE_PATH -> macOS bootstrap file -> ~/.omlx.
        let baseDirectory: URL
        if let override = env["OMLX_BASE_PATH"], !override.isEmpty {
            baseDirectory = URL(fileURLWithPath: (override as NSString).expandingTildeInPath, isDirectory: true)
        } else {
            let bootstrap = home.appendingPathComponent("Library/Application Support/oMLX/base-path")
            if let value = try? String(contentsOf: bootstrap, encoding: .utf8)
                .trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty {
                baseDirectory = URL(fileURLWithPath: (value as NSString).expandingTildeInPath, isDirectory: true)
            } else {
                baseDirectory = home.appendingPathComponent(".omlx", isDirectory: true)
            }
        }

        // Missing settings means oMLX's documented default is used.
        let settingsURL = baseDirectory.appendingPathComponent("settings.json")
        var settings: [String: Any] = [:]
        if FileManager.default.fileExists(atPath: settingsURL.path) {
            let data = try Data(contentsOf: settingsURL)
            guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw DetectionError.invalidConfig
            }
            settings = object
        }
        let server = settings["server"] as? [String: Any] ?? [:]
        let auth = settings["auth"] as? [String: Any] ?? [:]

        let hostSetting = env["OMLX_HOST"] ?? server["host"] as? String ?? "127.0.0.1"
        let firstHost = hostSetting.split(separator: ",").first.map(String.init)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? "127.0.0.1"
        // Never forward the main API key to a remote host. This extension is
        // explicitly designed for the user's single local oMLX instance.
        let normalizedHost: String
        switch firstHost.lowercased() {
        case "", "localhost", "127.0.0.1", "0.0.0.0", "::": normalizedHost = "127.0.0.1"
        case "::1", "[::1]": normalizedHost = "::1"
        default: throw DetectionError.nonlocalHost
        }

        let port: Int
        if let envPort = env["OMLX_PORT"], !envPort.isEmpty {
            guard let p = Int(envPort) else { throw DetectionError.invalidPort }
            port = p
        } else if let p = server["port"] as? Int {
            port = p
        } else {
            port = 8000
        }
        guard (1...65535).contains(port) else { throw DetectionError.invalidPort }

        var components = URLComponents()
        components.scheme = "http"
        components.host = normalizedHost
        components.port = port
        guard let url = components.url else { throw DetectionError.invalidConfig }
        let value = env["OMLX_API_KEY"] ?? auth["api_key"] as? String
        return OMLXConnection(baseURL: url, apiKey: value?.isEmpty == true ? nil : value)
    }

    func request(path: String, query: [URLQueryItem] = [], timeout: TimeInterval = 3) -> URLRequest {
        var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: false)!
        components.path = path
        components.queryItems = query.isEmpty ? nil : query
        var result = URLRequest(url: components.url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        result.setValue("application/json", forHTTPHeaderField: "Accept")
        if let apiKey { result.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization") }
        return result
    }
}
